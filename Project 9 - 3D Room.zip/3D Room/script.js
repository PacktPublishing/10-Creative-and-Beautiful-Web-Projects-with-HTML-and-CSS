document.querySelector(".btn").addEventListener("click", () => {
  document.querySelector(".table").classList.toggle("change");
});
